public class Main {
    public static void main(String[] args) throws Exception {
        Input input = new Input();
        Calculator calculator = new Calculator(input);
        calculator.go();
    }
}
